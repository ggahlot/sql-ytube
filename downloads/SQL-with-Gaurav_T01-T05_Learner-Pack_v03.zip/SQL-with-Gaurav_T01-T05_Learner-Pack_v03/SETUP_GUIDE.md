# Set up your SQL with Gaurav practice lab

Use this guide with [START_HERE.md](START_HERE.md). It covers Windows, Microsoft SQL Server and SQL Server Management Studio (SSMS). Use your own learning environment, separate from real work data.

## 1. The engine and the tool

SQL Server is the **database engine**: it stores data and carries out queries. SSMS is the **client tool**: you write instructions there and view the answers. Installing SSMS alone does not install the engine.

If you need either component, follow Microsoft's current instructions:

- [SQL Server downloads](https://www.microsoft.com/en-us/sql-server/sql-server-downloads): Express is free; Developer editions are free for non-production development and testing. Check the current licence and system requirements for your choice.
- [Install SSMS](https://learn.microsoft.com/en-us/ssms/install/install).
- [Connect to SQL Server using SSMS](https://learn.microsoft.com/en-us/ssms/quickstarts/ssms-connect-query-sql-server): use its connection guidance; the exercises in this pack use the included course files.

Open SSMS and connect to your own **Database Engine** with **Windows Authentication**, using the instance name from your installation or administrator. Your Windows account must already have the permissions needed for the relevant step. If you cannot connect, check that the engine is installed and that you selected the intended instance and Windows Authentication. For a permission or certificate error, keep the exact Messages text and use the connection guide above or the person managing your instance; do not bypass security checks. The data checks below apply only after you have connected.

## 2. Choose the right starting point

The lessons use two separate databases:

| Database | Purpose | When a new, unused name is required |
|---|---|---|
| `PracticeDB` | T01's small hand-built practice table | Only when running T01 blocks A–D for the first time |
| `FableMangoDB` | The prepared store data for T02–T05 | Only when running the course setup for the first time |

**First-time learner:** follow sections 3–5 in order. Before each creation step, check the Databases list in Object Explorer, refreshing it if needed. The relevant name must be unused on the connected instance.

**Returning learner:** do not repeat creation or inserts just to follow the video again. If `PracticeDB` already exists, stop before A–D and confirm its state, or read those steps without executing them. This does not prevent using an existing course database for later lessons.

If `FableMangoDB` already exists, **skip the setup file**. Choose it in the SSMS database dropdown and use the read-only checks in section 6 before continuing to the lessons. A matching name alone is not proof of the correct data. If a check fails or the database's history is unknown, follow the recovery choices in section 7. Do not restart setup over an existing database.

## 3. T01: build the small practice database

Open [T01_practice.sql](lessons/T01/T01_practice.sql) in SSMS. The learner copy labels its steps **Block A** through **Block E**. Follow those labels in order.

**Run only the intended selection.** With no text selected, Execute can run the whole query window. Never execute this entire file at once: E belongs after the separate course setup. Work through A–D in order, checking each step before continuing.

The existing `GO` lines separate batches for SSMS. Within a block containing several batches, select and execute one batch at a time, including its existing `GO` where present; check Messages before selecting the next batch. `GO` is a tool command, not a server SQL statement. See [Microsoft's GO reference](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/sql-server-utilities-statements-go?view=sql-server-ver17).

| Block | What the existing SQL does | Check before continuing |
|---|---|---|
| A | Creates `PracticeDB`, then selects it | Creation and context selection succeed. If the database already exists or either batch fails, stop. |
| B | Checks the current database name | The result is `PracticeDB`. |
| C | Creates the `Categories` table | Messages show successful completion. |
| D | Inserts the example categories, then reads them | The recorded example contains five rows: GPUs, CPUs, Motherboards, RAM and NVMe Storage. |

Keep the intended practice connection and database context throughout. If B reports another database, stop before creating the table. Do not rerun C or D after they have succeeded. The category query does not promise a row order.

## 4. Create the course database once

This step is needed only if `FableMangoDB` is absent and you are starting a fresh lab. The `Categories` table inside `PracticeDB` does not replace the course setup.

1. Open [the included course setup](setup/00_fablemango_schema.sql) in SSMS. Review it before execution: it creates `FableMangoDB`, selects it, creates the course tables and inserts the sample data.
2. Select and execute its first batch, which creates the database. Check Messages before doing anything else.
3. Only after creation succeeds, select and execute the next existing batch, which chooses `FableMangoDB`. Confirm the query window's database selector shows that name.
4. Continue through the remaining existing batches in file order, checking Messages after each. Keep the SQL unchanged.

**The setup has no existing-database guard.** It is not safe to repeat as a reset. Its multiple `GO` batches are not one all-or-nothing operation; do not rely on an error to prevent later work. If any error appears, stop executing further batches. Keep the error text, check the selected instance/database and use sections 6–7 to assess the next step. Do not rerun the file, repeat inserts or resume at a guessed line.

After successful setup, return to the T01 practice file and run **block E only**. It selects the existing course database and checks its name. The expected name is `FableMangoDB`. This name check confirms context, not every table or row in the database.

## 5. Continue with T02–T05

Open the relevant lesson files under `lessons/T02/` through `lessons/T05/`, following [LESSON_GUIDE.md](LESSON_GUIDE.md) for the exact file order and prerequisites.

For each lesson query window, choose **FableMangoDB** from the SSMS database dropdown before execution. Check the selector again after opening another tab or reconnecting. Use the existing SQL files; no extra context-changing statements are needed in them. Compare with the lesson's recorded answer, including any stated ordering limitations.

T05 also uses the temporary practice table `#CycleCount`. Its setup and Q3 must use the **same live connection**. Follow the lesson guide's order in the same query window/connection; a different query tab must not be assumed to share it. The temporary count sheet is separate from the store's stock figures. Its recovery steps are in section 7 and do not require a permanent database reset.

## 6. Check an existing course database without changing it

Choose **FableMangoDB** in the SSMS database dropdown. Open and execute these existing read-only files one at a time, without changing their SQL:

| File | Recorded check |
|---|---|
| [T05_Q0.sql](lessons/T05/T05_Q0.sql) | `Products` = **10** |
| [T05_Q1.sql](lessons/T05/T05_Q1.sql) | `Units` = **435** |
| [T05_Q2.sql](lessons/T05/T05_Q2.sql) | `WarehouseValue` = **175715.65** |
| [T02_Q3a.sql](lessons/T02/T02_Q3a.sql) | **6 country rows**, including Canada twice |

These are **coarse starting-data checks**, not proof that every table, key or value matches the course. The country query has no `ORDER BY`, so its displayed row order can differ. A mismatch or error is a reason to stop and inspect the selected database and earlier Messages, not to run setup again. Matching checks also do not turn a partially completed setup into a verified clean installation.

## 7. Recover the affected step

**Course setup or permanent-data mismatch:** first check the connected instance, database dropdown and earlier Messages. Do not repeat database creation, table creation or inserts to make an answer resemble the video. If the course database is partial, altered or still uncertain after the read-only checks, leave it untouched while deciding how to proceed.

The [public course README](https://github.com/ggahlot/sql-ytube) describes an **optional, deliberate destructive reset on your own disposable practice lab**. It deletes `FableMangoDB` and anything you added there. Read those recovery instructions before choosing that route; this guide does not add reset SQL or ask you to reset a database containing work you need. A deliberate reset is separate from rerunning setup over an existing database. After any chosen recovery, use the first-time route and its batch-by-batch checks only when the database name is unused again.

**T01 practice step mismatch:** check the selected database and the last successful block. Do not repeat A, C or D after success. If you cannot establish the state of an existing `PracticeDB`, read A–D without executing them; the separate course database can still be checked using section 6.

**T05 temporary-table error or lost connection:** close the old query window/connection so that session ends and its local temporary table is released. Open a new SSMS query window with a **new connection**, choose `FableMangoDB`, and run [T05_Q3-setup.sql](lessons/T05/T05_Q3-setup.sql) **once**. Copy the unchanged text from [T05_Q3.sql](lessons/T05/T05_Q3.sql) into that same live window, then select and execute **only Q3**. Its recorded result is `SheetRows` **5**, `Counted` **3**, `TotalCounted` **36**, `AvgCounted` **12**. Opening the two files in separate connected windows does not share their temporary table. This recovery changes no permanent course table and needs no permanent database reset.

Individual lesson statements and readbacks were checked in existing environments. **A full clean-server, end-to-end rehearsal of this download pack has not been performed.** The recorded examples do not guarantee success on every installation. Follow current vendor guidance and resolve a failed checkpoint before continuing.

FableMango is fictitious. This pack is for education. This course is not affiliated with or endorsed by Microsoft.
