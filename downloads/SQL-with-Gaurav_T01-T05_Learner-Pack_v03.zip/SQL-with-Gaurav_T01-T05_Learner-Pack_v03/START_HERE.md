# SQL with Gaurav — lessons 1–5 learner pack

Start with [SETUP_GUIDE.md](SETUP_GUIDE.md), then use [LESSON_GUIDE.md](LESSON_GUIDE.md) to choose one lesson file at a time. Try the questions in [PRACTICE.md](PRACTICE.md) before opening [ANSWERS.md](ANSWERS.md).

This pack contains the existing course setup, the exact lesson SQL and a short practice guide. All executable SQL is unchanged. T01's learner comments and line endings were cleaned; the other 28 SQL files are exact source copies. There is no automatic installer or run-all script.

## Choose your starting point

- **New to the course:** follow the first-time setup route. The hand-built PracticeDB sandbox and the FableMangoDB course database are separate.
- **Already using the course database:** skip creation/setup steps that you have completed. Use the existing read-only starting-data checks in [SETUP_GUIDE.md, section 6](SETUP_GUIDE.md#6-check-an-existing-course-database-without-changing-it). Do not repeat setup or inserts just to reopen a lesson.
- **Unsure what is already installed or created:** follow the setup guide's connection, database and Messages checks. Its recovery section separates temporary-table recovery from an optional destructive reset described in the public course README. Never rerun setup over an existing database.

Use your own practice or development SQL Server. Connect using your own authorized account. No server address, login or password is supplied by this pack.

## Files and lessons

[Full course playlist: SQL with Gaurav: Learn SQL Server from Zero](https://www.youtube.com/playlist?list=PLYJOoqQqSPRE).

| Lesson | Watch | SQL location | What you practise |
|---|---|---|---|
| T01 | [What Is SQL? DDL, DML and Your First SQL Server Lab](https://youtu.be/XvDNOwEulVc) | [T01_practice.sql](lessons/T01/T01_practice.sql) | Engine/tool/database, a practice table and the current database |
| T02 | [Your First SQL Query: SELECT, FROM, AS and DISTINCT](https://youtu.be/2pWSnosGZsI) | [T02 files](lessons/T02/) | Columns, headings and DISTINCT |
| T03 | [SQL WHERE Explained: AND, OR, IN, BETWEEN and LIKE](https://youtu.be/ixBuxz0tmpI) | [T03 files](lessons/T03/) | Tests, patterns, ranges and brackets |
| T04 | [SQL ORDER BY, TOP and OFFSET FETCH: Sorting and Paging](https://youtu.be/oVfisNzc4oY) | [T04 files](lessons/T04/) | ORDER BY, TOP and pages |
| T05 | [SQL Aggregate Functions: COUNT, SUM, AVG, MIN, MAX](https://youtu.be/Yd9Z5f3X7Zc) | [T05 files](lessons/T05/) | Counts, totals, averages and NULLs |

The separate [course setup script](setup/00_fablemango_schema.sql) creates and fills FableMangoDB. It is a first-time setup file, not a lesson query to repeat. Read the setup guide before executing it.

## A useful way to practise

1. Watch the question and pause before its answer.
2. Predict the result or explain which rows should qualify.
3. Open the corresponding unchanged SQL file listed in the lesson guide. Check its database/session prerequisites before executing it.
4. Compare with the recorded answer. For examples without ORDER BY, compare the values and rows rather than their display sequence.
5. Explain why the result answers the business question.

T04 contains intentional trap/error files; they are identified in the lesson guide. T05's temporary practice table must be created and queried in the same live connection. If that connection is lost or its temporary-table state is uncertain, use the setup guide's temporary-table recovery steps; a permanent database reset is not needed. Do not execute every file in the pack together.

## Verification and credits

The lessons include historical runs and later captured readbacks. This pack has not been executed start to finish on a fresh SQL Server. See [CREDITS_AND_LIMITS.md](CREDITS_AND_LIMITS.md) for that distinction, source links and licence information. File hashes and source lineage are recorded in `MANIFEST.json`; `SHA256SUMS.txt` lets you check an extracted copy.

© 2026 Gaurav Gahlot. Produced by FableMango Studio. Not affiliated with or endorsed by Microsoft.
