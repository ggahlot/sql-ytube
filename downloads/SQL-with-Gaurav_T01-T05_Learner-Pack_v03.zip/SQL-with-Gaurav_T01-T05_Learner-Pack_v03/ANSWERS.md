# Answers to lessons 1–5

Use this after attempting the [practice questions](PRACTICE.md). The answers use the existing lesson examples and recorded results; they are not a claim that you have run the queries successfully on your machine.

For starting instructions, see the [setup guide](SETUP_GUIDE.md) and [lesson guide](LESSON_GUIDE.md). The complete setup has not yet been tested from start to finish.

## Lesson 1: Know where you are

[Watch lesson 1](https://youtu.be/XvDNOwEulVc) · [Practice run sheet, sections A–E](lessons/T01/T01_practice.sql)

**Prediction:** Use the database-name check already demonstrated in lesson 1 and included in the run sheet. PracticeDB is the hand-built sandbox. FableMangoDB is the separate lesson database supplied by the course setup. Check the displayed name before continuing; do not assume every fresh connection starts in the same database.

**Explanation:** SQL Server is the engine that runs the database work. SQL Server Management Studio (SSMS) is the client tool used to send queries and view results. A database is the named place containing the lesson's tables and data. The tool, engine and database have different jobs.

## Lesson 2: Choose what comes back

[Watch lesson 2](https://youtu.be/2pWSnosGZsI) · [Q1b](lessons/T02/T02_Q1b.sql) · [Q2](lessons/T02/T02_Q2.sql) · [Q3a](lessons/T02/T02_Q3a.sql) · [Q3](lessons/T02/T02_Q3.sql)

**Prediction:** Q1b puts UnitPrice before ProductName. Q2 labels its result columns Product and PriceUSD. These examples change the returned layout or headings, not the stored column names.

**Explanation:** Q3a returns the selected Country value for each customer. Q3 removes repeated selected rows, leaving five country rows from the existing six. Neither query asks for a grouped customer count. DISTINCT compares the complete selected row; here, that row contains only Country. See [Microsoft Learn: SELECT clause](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-clause-transact-sql?view=sql-server-ver17).

## Lesson 3: Predict the bracket trap

[Watch lesson 3](https://youtu.be/ixBuxz0tmpI) · [Q6](lessons/T03/T03_Q6.sql) · [Q7](lessons/T03/T03_Q7.sql)

**Prediction:** Q6 does not apply the price condition to both category choices. Category four can qualify independently of the price test, which is why the expensive memory kit passes. In Q7, the bracket pair groups the category alternatives, so the price condition applies to the grouped choice. The existing two-row Q6 result becomes the recorded one-row Q7 result.

**Explanation:** Point to the brackets around the category alternatives in Q7. In ordinary words: choose memory or storage, with the price limit applying to either choice. This describes the logical condition, not the engine's physical execution order.

## Lesson 4: Work out the next page

[Watch lesson 4](https://youtu.be/oVfisNzc4oY) · [Q5b](lessons/T04/T04_Q5b.sql) · [Q5c](lessons/T04/T04_Q5c.sql)

**Prediction:** Q5b skips the first four rows and returns G40 Legacy at 549.99, X900 Pro Wireless at 389.99, MangoDrive Gen5 4TB at 349.99 and DDR5 64GB at 229.99, in that order. Q5c skips eight; only the two remaining recorded products are available. Compare with the unchanged lesson results rather than expecting four rows on every page.

**Explanation:** ProductID breaks ties to supply a unique ordering. Stable page requests also require unchanged underlying data. Both conditions matter; see [Microsoft Learn: ORDER BY and paging](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-order-by-clause-transact-sql?view=sql-server-ver17).

## Lesson 5: Choose the right count

[Watch lesson 5](https://youtu.be/Yd9Z5f3X7Zc) · [Q3-setup](lessons/T05/T05_Q3-setup.sql) · [Q3](lessons/T05/T05_Q3.sql)

**Prediction:** Counted answers the question: three recorded quantities. SheetRows is five. Two quantities are NULL, meaning no recorded quantity here; NULL is not a recorded zero. The existing non-NULL quantities total 36, so the demonstrated average is 12 over three recorded values.

**Explanation:** Match the question to its existing result heading:

| Business question | Existing answer |
|---|---|
| Product records | [Q0](lessons/T05/T05_Q0.sql): Products |
| Stock units | [Q1](lessons/T05/T05_Q1.sql): Units |
| Warehouse value | [Q2](lessons/T05/T05_Q2.sql): WarehouseValue |

Those are different questions. AVG uses the non-NULL values, as documented in [Microsoft Learn: AVG](https://learn.microsoft.com/en-us/sql/t-sql/functions/avg-transact-sql?view=sql-server-ver17).

Q3-setup and Q3 belong in the **same live connection**, with the fixture created first. The fixture is practice data, not the store's stock figures. Repeat Q3 alone for another read. For a fresh fixture, end the old connection, open a new connected query window, choose FableMangoDB, run Q3-setup once and then Q3 in that window.
