# Sources, licence and verification limits

This pack accompanies the first five SQL with Gaurav lessons. FableMango and its people, products and example data are fictitious.

## SQL and source records

All executable SQL statements, values and batch separators are unchanged from the reviewed course examples. Twenty-eight SQL files are byte-for-byte source copies. The T01 learner copy has a replacement learner header, clearer Block A–E comments and consistent LF line endings. It removes internal screenshot/approval notes. Its executable lines and all five GO separators remain exact; the original source and v01 copy are preserved. `MANIFEST.json` records both hashes and this comment-only change.

The setup and lesson statements have historical SQL Server runs and later readbacks. Some full companion statements were previously derived from lesson shorthand and reviewed before this pack; their lineage stays in the manifest. No query was created, changed or run to prepare this revision. The lesson checks are recorded answers, not a claim of a new complete pack run.

## What has and has not been checked

- File identities, SQL preservation, local links, practice answers and archive integrity are checked separately from server execution.
- **A clean-server, start-to-finish rehearsal remains unperformed.** Individual historical answers do not prove a fresh installation or every table/row in a learner's database.
- The four read-only checks in the setup guide are useful starting-state checks. Matching them is not a complete database audit. A mismatch is a reason to check context and setup history, not to repeat inserts.
- The setup has no existing-database guard or automatic reset. Run its first batch separately, stop on any error and check each later batch. Do not rely on an error to prevent subsequent work.
- The [public course README](https://github.com/ggahlot/sql-ytube#how-to-run-it) describes an optional destructive restart for a learner's own disposable practice database. It deletes that database and anything added to it. This pack supplies no reset/helper SQL and performs no reset. Follow the setup guide's recovery choices before deciding whether to use those separate instructions.
- A local temporary table belongs to its session and is removed when that session ends. T05 recovery uses a new connection and the existing fixture/query, without rebuilding permanent data.
- Row order is not guaranteed without ORDER BY. Stable T04 pages also require the unchanged course data and the existing unique ordering.

## Course and primary references

- [Public course repository](https://github.com/ggahlot/sql-ytube)
- [SQL with Gaurav course playlist](https://www.youtube.com/playlist?list=PLYJOoqQqSPRE)
- [Microsoft SQL Server downloads](https://www.microsoft.com/sql-server/sql-server-downloads)
- [Install SQL Server Management Studio](https://learn.microsoft.com/en-us/ssms/install/install)
- [Microsoft Learn: connect and query in SSMS](https://learn.microsoft.com/en-us/ssms/quickstarts/ssms-connect-query-sql-server)
- [Microsoft Learn: SELECT](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-clause-transact-sql?view=sql-server-ver17)
- [Microsoft Learn: ORDER BY and paging](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-order-by-clause-transact-sql?view=sql-server-ver17)
- [Microsoft Learn: AVG return types](https://learn.microsoft.com/en-us/sql/t-sql/functions/avg-transact-sql?view=sql-server-ver17)
- [Microsoft Learn: temporary tables](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-table-transact-sql?view=sql-server-ver17#temporary-tables)

Software, downloads and terms change. Check current vendor guidance and test in a practice environment. No Microsoft software, screenshots, icons, fonts, voice recordings or videos are bundled in this pack.

## Licence

[LICENSE](LICENSE) preserves the existing public course repository's MIT text and copyright notice. It does not grant rights to the course videos, Microsoft software/documentation or material on linked websites; their respective rights remain with their owners.

The MIT licence covers all files in this learner pack, including the SQL files, setup and lesson guides, practice questions and answer key.

© 2026 Gaurav Gahlot. Produced by FableMango Studio. Not affiliated with or endorsed by Microsoft.
