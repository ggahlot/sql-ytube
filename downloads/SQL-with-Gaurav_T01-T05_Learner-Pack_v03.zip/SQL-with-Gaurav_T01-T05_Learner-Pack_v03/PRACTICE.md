# Practise lessons 1–5

Predict first, compare with the lesson's existing example, then explain the result in your own words. Keep the [answer key](ANSWERS.md) closed until you have tried each challenge.

The complete setup has not yet been tested from start to finish.

## Before you start

Read the [setup guide](SETUP_GUIDE.md) for the starting database and prerequisites, then use the [lesson guide](LESSON_GUIDE.md) to find each example. The [public repository](https://github.com/ggahlot/sql-ytube) supplies the course setup script, README and licence. This pack adds the lesson SQL files, guides, questions and answers.

Use the unchanged examples. You do not need to rerun database setup or data-changing examples just to repeat a reading exercise. For a prediction, cover the result in the video or read the query without running it first.

## Lesson 1: Know where you are

[Watch lesson 1](https://youtu.be/XvDNOwEulVc) · [Existing practice run sheet, sections A–E](lessons/T01/T01_practice.sql)

**Predict:** Before creating a table, how can you check which database your connection is using? Which database is the practice sandbox?

**Explain:** Describe the difference between the engine, the client tool and a database without using the restaurant comparison.

[Check your answers](ANSWERS.md#lesson-1-know-where-you-are).

## Lesson 2: Choose what comes back

[Watch lesson 2](https://youtu.be/2pWSnosGZsI) · [Q1b](lessons/T02/T02_Q1b.sql) · [Q2](lessons/T02/T02_Q2.sql) · [Q3a](lessons/T02/T02_Q3a.sql) · [Q3](lessons/T02/T02_Q3.sql)

**Predict:** Cover Q1b and Q2's results. Predict the column order and headings. Does either example rename a stored table column?

**Explain:** Q3a has six country rows; Q3 has five distinct country rows. Why does neither result count the number of customers per country?

[Check your answers](ANSWERS.md#lesson-2-choose-what-comes-back).

## Lesson 3: Predict the bracket trap

[Watch lesson 3](https://youtu.be/ixBuxz0tmpI) · [Q6](lessons/T03/T03_Q6.sql) · [Q7](lessons/T03/T03_Q7.sql)

**Predict:** Cover Q6 and Q7's results. Does Q6 apply the price limit to both category choices? Why does the expensive memory kit pass?

**Explain:** Point to the bracket pair that expresses the business rule. Say the rule in ordinary words before reading the SQL.

[Check your answers](ANSWERS.md#lesson-3-predict-the-bracket-trap).

## Lesson 4: Work out the next page

[Watch lesson 4](https://youtu.be/oVfisNzc4oY) · [Q5b](lessons/T04/T04_Q5b.sql) · [Q5c](lessons/T04/T04_Q5c.sql)

**Predict:** Cover Q5b's result. Locate its four products in the full ordered list shown in the lesson. Why does Q5c return only two products?

**Explain:** What does the ProductID tie breaker contribute to paging? What must also remain unchanged between page requests?

[Check your answers](ANSWERS.md#lesson-4-work-out-the-next-page).

## Lesson 5: Choose the right count

[Watch lesson 5](https://youtu.be/Yd9Z5f3X7Zc) · [Q3-setup](lessons/T05/T05_Q3-setup.sql) · [Q3](lessons/T05/T05_Q3.sql) · [Q0](lessons/T05/T05_Q0.sql) · [Q1](lessons/T05/T05_Q1.sql) · [Q2](lessons/T05/T05_Q2.sql)

If you run Q3, first create its practice fixture with Q3-setup **in the same live connection**. Keep that connection open. Select only Q3 when repeating a read. To restart the fixture, end the old connection and use a new connected query window: select FableMangoDB, run Q3-setup once, then Q3 in that same window. This does not require rebuilding the course database.

**Predict:** You need the number of recorded quantities on the practice count sheet. Which Q3 heading answers that question: SheetRows or Counted?

**Explain:** Match each business question to an existing answer: product records, stock units and warehouse value.

[Check your answers](ANSWERS.md#lesson-5-choose-the-right-count).
