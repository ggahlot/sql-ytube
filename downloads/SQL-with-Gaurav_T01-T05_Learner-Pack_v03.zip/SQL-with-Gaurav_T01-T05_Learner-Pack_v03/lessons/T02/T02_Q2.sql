SELECT ProductName AS Product,
       UnitPrice   AS PriceUSD
FROM Products;