SELECT ProductName, UnitPrice
FROM Products
WHERE UnitPrice BETWEEN 119.99 AND 229.99;