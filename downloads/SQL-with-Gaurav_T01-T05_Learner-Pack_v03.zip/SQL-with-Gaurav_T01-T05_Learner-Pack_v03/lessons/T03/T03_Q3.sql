SELECT ProductName, UnitPrice
FROM Products
WHERE ProductName LIKE '%DDR5%'
  AND UnitPrice < 150;