SELECT ProductName, UnitPrice
FROM Products
WHERE CategoryID = 4 OR CategoryID = 5
  AND UnitPrice < 150;