SELECT ProductName, UnitPrice
FROM Products
WHERE CategoryID IN (4, 5);