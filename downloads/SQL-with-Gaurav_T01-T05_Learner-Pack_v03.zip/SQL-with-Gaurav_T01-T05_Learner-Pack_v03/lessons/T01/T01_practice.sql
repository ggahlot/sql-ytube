-- T01 learner practice: run one labelled block at a time.
-- Start A-D only when PracticeDB is unused on your own practice server.
-- Check each step before continuing; do not execute the whole file.
-- Before E, complete the separate FableMangoDB course setup once.
-- Do not repeat a creation or insert step that has already succeeded.
-- Read SETUP_GUIDE.md before executing any selection.

-- Block A: create and choose the practice database.
CREATE DATABASE PracticeDB;
GO
USE PracticeDB;
GO

-- Block B: confirm the current database.
SELECT DB_NAME();

-- Block C: create the table.
CREATE TABLE Categories (
    CategoryID   INT PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL
);
GO

-- Block D: insert and read the rows.
INSERT INTO Categories (CategoryID, CategoryName)
VALUES (1, 'GPUs'), (2, 'CPUs'), (3, 'Motherboards'),
       (4, 'RAM'), (5, 'NVMe Storage');
GO
SELECT * FROM Categories;

-- Block E: choose the existing course database after its separate setup.
-- Do not repeat course setup just to repeat a lesson.
USE FableMangoDB;
GO
SELECT DB_NAME();
