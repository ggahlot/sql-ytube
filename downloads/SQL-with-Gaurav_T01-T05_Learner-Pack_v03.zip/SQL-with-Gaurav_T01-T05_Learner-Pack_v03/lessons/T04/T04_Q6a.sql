SELECT TOP (3) ProductName, UnitPrice
FROM Products;