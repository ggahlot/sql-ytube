SELECT COUNT(*) AS Products
FROM Products;