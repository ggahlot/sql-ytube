SELECT SUM(StockQuantity) AS Units,
       MIN(UnitPrice)     AS Cheapest,
       MAX(UnitPrice)     AS Priciest,
       AVG(UnitPrice)     AS AvgPrice
FROM Products;