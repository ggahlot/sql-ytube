SELECT SUM(UnitPrice * StockQuantity) AS WarehouseValue
FROM Products;