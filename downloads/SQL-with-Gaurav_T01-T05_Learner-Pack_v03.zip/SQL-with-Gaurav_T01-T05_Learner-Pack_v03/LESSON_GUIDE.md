# Follow along with lessons 1–5

Read [SETUP_GUIDE.md](SETUP_GUIDE.md) first. Use your own authorized SQL Server practice environment and SSMS connection. Work through one file or labelled block at a time; this pack has no run-all sequence.

The answers below use the course starting data. A database you have changed can return different answers. Without `ORDER BY`, compare rows and values rather than their display sequence. The full clean-installation route has not yet been rehearsed; source and verification details are in [CREDITS_AND_LIMITS.md](CREDITS_AND_LIMITS.md).

Try [PRACTICE.md](PRACTICE.md) before checking [ANSWERS.md](ANSWERS.md).

## T01 — your practice database, then the course database

Open [T01_practice.sql](lessons/T01/T01_practice.sql). It is a staged run sheet, not one script to execute from top to bottom. Select only the next labelled block. `PracticeDB` must be unused before Block A; if it or the practice table already exists, follow the setup guide rather than repeating creation or inserts.

| Order | Label in the file | What it does | Recorded check |
|---|---|---|---|
| 1 | Block A | Creates and chooses `PracticeDB` | Database creation and context change succeed |
| 2 | Block B | Reads the current database name | One cell: `PracticeDB` |
| 3 | Block C | Creates `Categories` in `PracticeDB` | Table creation succeeds |
| 4 | Block D | Inserts five categories, then reads the table | Five inserted rows; the grid has five rows and two columns |

The recorded category pairs are **1 — GPUs; 2 — CPUs; 3 — Motherboards; 4 — RAM; 5 — NVMe Storage**. Their displayed order is not guaranteed by this query.

**Pause before Block E.** Follow the setup guide to create and fill the separate `FableMangoDB` course database once, if you have not already completed that setup. Then run **Block E**: it chooses the existing course database and reads its name. The recorded cell is `FableMangoDB`. Block E does not install the course data.

## T02 — choose columns and remove repeated countries

Prerequisite: the course setup is complete. Select **FableMangoDB** in the SSMS database dropdown. These files read `Products` or `Customers`; they do not create or change them.

Run the six files in this order:

| File | What to notice | Recorded check |
|---|---|---|
| [T02_Q0.sql](lessons/T02/T02_Q0.sql) | Peek at every product column | 10 rows, 6 columns |
| [T02_Q1.sql](lessons/T02/T02_Q1.sql) | Choose product names and prices | 10 rows, 2 columns |
| [T02_Q1b.sql](lessons/T02/T02_Q1b.sql) | Swap the selected columns | Same 10 rows, columns swapped |
| [T02_Q2.sql](lessons/T02/T02_Q2.sql) | Rename the result headings | Same data; headings `Product` and `PriceUSD` |
| [T02_Q3a.sql](lessons/T02/T02_Q3a.sql) | Read the countries before removing repeats | 6 rows; Canada appears twice |
| [T02_Q3.sql](lessons/T02/T02_Q3.sql) | Read each selected country once | 5 countries: Canada, Germany, India, United Kingdom, United States |

**Run Q3a before Q3.** The recorded Q3 result looks alphabetical, but `DISTINCT` does not promise a sort order. Neither country query has `ORDER BY`.

## T03 — filter, then compare the trap and fix

Prerequisite: **FableMangoDB** selected, with the unchanged `Products` data. All seven files read data.

| File, in order | Recorded check |
|---|---|
| [T03_Q1.sql](lessons/T03/T03_Q1.sql) | 1 row: the DDR5 32GB kit at 119.99 |
| [T03_Q2.sql](lessons/T03/T03_Q2.sql) | 2 DDR5 rows: 64GB at 229.99 and 32GB at 119.99 |
| [T03_Q3.sql](lessons/T03/T03_Q3.sql) | 1 row after combining the pattern and price tests |
| [T03_Q4.sql](lessons/T03/T03_Q4.sql) | 3 rows from categories 4 and 5 |
| [T03_Q5.sql](lessons/T03/T03_Q5.sql) | 3 prices: 119.99, 219.99 and 229.99; both range endpoints qualify |
| [T03_Q6.sql](lessons/T03/T03_Q6.sql) **Trap** | 2 rows: both DDR5 kits, including the 229.99 kit that misses the intended price limit |
| [T03_Q7.sql](lessons/T03/T03_Q7.sql) **Fix** | 1 row: the 119.99 kit |

Compare Q6 with Q7 before moving on: the parentheses change which tests belong together. These queries do not promise row order.

## T04 — sorting and pages, with traps kept separate

Prerequisite: **FableMangoDB** selected and the same unchanged product data throughout the page comparison. All files are read-only examples; Q6b deliberately fails.

Follow this normal sequence first:

| File, in order | Recorded check |
|---|---|
| [T04_Q1.sql](lessons/T04/T04_Q1.sql) | 10 rows, price ascending: 119.99 first, 1999.99 last |
| [T04_Q2.sql](lessons/T04/T04_Q2.sql) | 10 rows, price descending: 1999.99 first, 119.99 last |
| [T04_Q3.sql](lessons/T04/T04_Q3.sql) | 10 rows, category first, then price descending within each category |
| [T04_Q4.sql](lessons/T04/T04_Q4.sql) | Top 3 prices: 1999.99, 1199.99, 649.99 |
| [T04_Q5a.sql](lessons/T04/T04_Q5a.sql) | Page 1: 4 rows |
| [T04_Q5b.sql](lessons/T04/T04_Q5b.sql) | Page 2: 4 rows |
| [T04_Q5c.sql](lessons/T04/T04_Q5c.sql) | Page 3: 2 rows, B600 Creator at 219.99 and DDR5 32GB at 119.99 |

The paging files include the existing `ProductID` tie-breaker. Keep the data unchanged while comparing pages.

Then examine these separately; **do not bulk-run the folder**:

- [T04_Q6a.sql](lessons/T04/T04_Q6a.sql): the unspecified-order trap. It returns three rows, but without `ORDER BY` neither their selection nor their sequence is guaranteed. Do not expect particular product names.
- [T04_Q6b.sql](lessons/T04/T04_Q6b.sql): **INTENTIONAL ERROR**, outside the normal sequence. It demonstrates paging without the required ordering clause. The recorded error includes “Incorrect syntax near '4'. Invalid usage of the option NEXT in the FETCH statement.” There is no result grid. Compare it with the already supplied valid Q5b file.

## T05 — aggregates, then a temporary count sheet

Prerequisite: **FableMangoDB** selected. Start with the three reads of `Products`:

| File, in order | Recorded single-row result |
|---|---|
| [T05_Q0.sql](lessons/T05/T05_Q0.sql) | `Products` = 10 |
| [T05_Q1.sql](lessons/T05/T05_Q1.sql) | `Units` = 435; `Cheapest` = 119.99; `Priciest` = 1999.99; `AvgPrice` = 633.990000 |
| [T05_Q2.sql](lessons/T05/T05_Q2.sql) | `WarehouseValue` = 175715.65 |

For the NULL example, use **one live SSMS query window and connection**:

1. Open [T05_Q3-setup.sql](lessons/T05/T05_Q3-setup.sql) in that window and execute it **once**. It creates and fills `#CycleCount`, a temporary practice count sheet. Its five supplied rows are demo counts, not the store's stock quantities.
2. Keep that window and connection open. Read [T05_Q3.sql](lessons/T05/T05_Q3.sql) and copy its **unchanged query text into the same live window** after the setup. Select only the Q3 query when executing it; do not select and repeat the setup.
3. Compare all four columns: **`SheetRows` 5; `Counted` 3; `TotalCounted` 36; `AvgCounted` 12**.

Opening the two files in separate connected query windows is not sufficient: another connection cannot see this local temporary table. For a fresh fixture, disconnect or close the old query window so its session ends. Open a new connected query window, select FableMangoDB, run the unchanged Q3-setup once, then paste and execute unchanged Q3 in that same window. End-of-session removes this local temporary table; it does not reset the permanent course database. For repeated reads in the existing session, select Q3 alone rather than repeating setup.

The two NULL quantities mean “not counted yet.” The recorded non-NULL counts are 12, 6 and 18. CountedQty is INT, so AVG returns INT. Here, 36 divided by 3 is exactly 12; an integer result cannot preserve a fraction. See [Microsoft Learn: AVG](https://learn.microsoft.com/en-us/sql/t-sql/functions/avg-transact-sql?view=sql-server-ver17).

## Which steps change something?

- The **series setup** creates and fills the course database; follow its first-time-only instructions.
- **T01 Block A** creates a database; **C** creates a table; **D** inserts rows. Block A and E also choose a database context. B reads the context; E reads it after choosing it.
- **T05 Q3-setup** creates and fills a session-local temporary table. Q3 reads it.
- The other supplied lesson queries read data; **T04 Q6b intentionally produces an error**.

No cleanup, reset or replacement SQL is bundled here. For course-database recovery choices, use [SETUP_GUIDE.md](SETUP_GUIDE.md). Evidence, source lineage and reuse limits are in [CREDITS_AND_LIMITS.md](CREDITS_AND_LIMITS.md); `MANIFEST.json` identifies the supplied files.
